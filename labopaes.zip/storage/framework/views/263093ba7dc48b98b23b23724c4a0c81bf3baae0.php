

<?php $__env->startSection('title','Proeevedores'); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\Endersonfs\Clientes\Labopaes\proyecto Laravel\labopaes\resources\views/proveedores/index.blade.php ENDPATH**/ ?>