

<?php $__env->startSection('title','Proveedores'); ?>
<?php $__env->startSection('contentpage'); ?>
<h1>proveedores: <?php echo($proveedor)?> </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Documents\Endersonfs\Clientes\Labopaes\proyecto Laravel\labopaes\resources\views/proveedores/show.blade.php ENDPATH**/ ?>