@extends('layouts.template')

@section('title','Proveedores')
@section('contentpage')
<h1>proveedores create</h1>
@endsection