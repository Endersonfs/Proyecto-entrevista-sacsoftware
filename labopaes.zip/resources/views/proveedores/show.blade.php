@extends('layouts.template')

@section('title','Proveedores')
@section('contentpage')
<h1>proveedores: <?php echo($proveedor)?> </h1>
@endsection